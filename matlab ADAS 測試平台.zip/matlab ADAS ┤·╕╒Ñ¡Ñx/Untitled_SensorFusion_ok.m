clear
clc
close all


[X_map_C, X_map_L, X_map_R]=getloopmap2();   %給你三線道%
% 'StopTime', 35  指的是 模擬跑35sec
sample_time=0.1;
scenario = drivingScenario('SampleTime',sample_time,'StopTime',35); 

roadCenters = [X_map_C(:,1), X_map_C(:,2)];
lm = [laneMarking('Solid','Color','w'); ...
    laneMarking('Dashed','Color','y'); ...
    laneMarking('Dashed','Color','y'); ...
    laneMarking('Solid','Color','w')];
ls = lanespec(3,'Marking',lm);
road(scenario,roadCenters,'Lanes',ls);



%% 

egoCar = vehicle(scenario, ...
    'ClassID',1, ...
    'Position',[X_map_C(21,1), X_map_C(21,2), 0]); % x, y, z %
egoCar.Yaw = X_map_C(1,3)*180/pi;





% Add a car in front of the ego vehicle
leadCar = vehicle(scenario, 'ClassID', 1);
trajectory(leadCar, X_map_R(35:end,1:2), 25); % On right lane

% Add a car that travels at 35 m/s along the road and passes the ego vehicle
passingCar = vehicle(scenario, 'ClassID', 2);
trajectory(passingCar, X_map_C(35:end,1:2), 24.8);

% Add a car behind the ego vehicle
chaseCar = vehicle(scenario, 'ClassID', 1);
trajectory(chaseCar, X_map_L(2:end,1:2), 25); % On right lane

%% Define Radar and Vision Sensors

sensors = MySensorSeting(egoCar);

% Register actor profiles with the sensors.
profiles = actorProfiles(scenario);

for m = 1:numel(sensors)

    if isa(sensors{m},'drivingRadarDataGenerator')  % radar matlab 格式要求
        sensors{m}.Profiles = profiles;
    else
        sensors{m}.ActorProfiles = profiles;  % vision matlab 格式要求
    end
end

%% Create a Tracker


% Create the display and return a handle to the bird's-eye plot
BEP = createDemoDisplay(egoCar, sensors);

%% Simulate the Scenario

givenpath=X_map_C;  % givenpath為本車行駛的路徑

toSnap = true;


while advance(scenario) && ishghandle(BEP.Parent)    
    % Get the scenario time
    time = scenario.SimulationTime;
    
    % Get the position of the other vehicle in ego vehicle coordinates
    other_vehicle = targetPoses(egoCar);
    
    % Simulate the sensors
    detectionClusters = {};
    isValidTime = false(1,numel(sensors));
    for i = 1:numel(sensors)
        [sensorDets,numValidDets,isValidTime(i)] = sensors{i}(other_vehicle, time);
        if numValidDets
            detectionClusters = [detectionClusters; sensorDets]; 
        end
    end
    
    % Update the tracker if there are new detections

    if any(isValidTime)      
        % Update bird's-eye plot
        detPos = updateBEP2(BEP, egoCar, detectionClusters);
    end
    
    % detPos 的資料為感測器打到的物體
    % 以row為單位表示, 例如:
    % row 1 為轎車在車座標的位置
    % row 2 為貨卡在車座標的位置


    velocity=25;   % 給定本車車速
    % lines 105-108 為Pure-persuit 演算法 
    temp1=egoCar.Position(1,1:2);
    temp2=deg2rad(egoCar.Yaw);
    ego_now=[temp1,temp2];
    ego_next = getnextegostate(velocity, ego_now, givenpath,sample_time);
    helperMoveEgoToState(egoCar, ego_next,velocity);




end


function ego_next = getnextegostate(velocity, ego_now, givenpath,DT)
% pure-persuit algorithm
    L=4.7;
    [heading_point] = lookahead4(velocity, ego_now, givenpath,DT);            % 決定預視點 heading point [x_map,y_map]^T
    delta_steer = steerang( ego_now, heading_point, L );                      % 算輪胎轉角 delta
    ego_next = vehicle_dynamic(ego_now,delta_steer,velocity,DT);              % 更新車輛動態 X_now := [x,y, heading]^T
    
end


function X = vehicle_dynamic(X_now,delta,velocity,DT)
% 計算本車的下一時刻位置
  L=4.5;
  X(1,1) = X_now(1,1)+velocity*cos(X_now(1,3))*DT; % car_in_map _x
  X(1,2) = X_now(1,2)+velocity*sin(X_now(1,3))*DT; % car_in_map_y
  X(1,3) = X_now(1,3)+velocity/L*(tan(delta))*DT;  % vehicle currentlt heading angle in map
  X(1,3) = mod(X(1,3),2*pi);
end


function helperMoveEgoToState(ego_car, ego_next,velocity)
% 更新 drivingScenario 的本車位置
ego_car.Position(1:2) = ego_next(1:2);
ego_car.Velocity(1:2) = [cos(ego_next(3)) sin(ego_next(3))]*velocity;
ego_car.Yaw = rad2deg(ego_next(3));
end



