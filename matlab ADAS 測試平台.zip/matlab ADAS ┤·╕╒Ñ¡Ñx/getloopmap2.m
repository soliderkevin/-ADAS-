function [outputArg1,outputArg2,outputArg3] = getloopmap2()
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

 X_map = getloopmap();
 [m,n]=size(X_map);
 for i=1:m
 theta=X_map(i,3);
 T = [cos(theta) -sin(theta); sin(theta) cos(theta)];
 temp_R=T*[0;-3.6];
 xtemp_R=temp_R';
 X_right(i,1:2)=X_map(i,1:2)+xtemp_R;
 X_right(i,3)=theta;

 temp_L=T*[0; 3.6];
 xtemp_L=temp_L';
 X_left(i,1:2)=X_map(i,1:2)+xtemp_L;
 X_left(i,3)=theta;
 end

outputArg1 = X_map;
outputArg2 = X_left;
outputArg3 = X_right;

end


function X_map = getloopmap()

% load SpaFrancorchamps
load Monza
% load Test_loop
[m,~]=size(X);
DT=0.1;
k=1;
path_length(1)=0;
for i=2:m
    temp_y=Y(i,1)-Y(i-1,1);
    temp_x=X(i,1)-X(i-1,1);
    temp_phi=atan2(temp_y,temp_x); % 航向角
    phi(k)=mod(temp_phi,2*pi);
    temp_s=temp_x^2+temp_y^2;
    s_arc(k,1)=sqrt(temp_s);
    path_length(i)=path_length(i-1)+s_arc(k,1);
    k=k+1;
end
remainingdist=flip(path_length);
X_map(:,1)=X(2:end,1)'; 
X_map(:,2)=Y(2:end,1)'; 
X_map(:,3)=phi';        % 航向角
X_map(:,4)=remainingdist(1:end-1)';
X_map(:,5)=zeros(m-1,1); % altitude

figure(99)
plot(X_map(:,1), X_map(:,2),'b');

end
